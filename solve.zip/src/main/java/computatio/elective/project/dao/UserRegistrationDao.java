package computatio.elective.project.dao;

import java.util.List;
import org.springframework.stereotype.Component;

import computatio.elective.project.model.User;

@Component
public interface UserRegistrationDao {
	public int saveUserRegistration(User user);
	public User findByEmail(String email);
	public List<User> listOfUsers();
	public User findUserById(int userId);
	public void updateUserRegistration(User user);
	public void deleteUserRegistration(String email);
	public void savePassword(String cppassword, String email);
}
