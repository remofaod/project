package computatio.elective.project.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import computatio.elective.project.model.User;

@Repository
public class UserRegistationDaoImpl implements UserRegistrationDao{

		@Autowired
		private JdbcTemplate jdbcTemplate;
		
		@Override
		public int saveUserRegistration(User user) {
			String sql = "INSERT INTO user(fullname, cppassword, email) VALUES('"+user.getFullname()+"','"+user.getCppassword()+"','"+user.getEmail()+"')";
			return jdbcTemplate.update(sql);
		}


		@Override
		public User findByEmail(String email) {
			String sql="SELECT * FROM user WHERE email='" + email +"'";
			return jdbcTemplate.queryForObject(sql,BeanPropertyRowMapper.newInstance(User.class)); //mas simple pero masmabagal kumpara sa ResultSet
		}
		
		
		@Override
		public List<User> listOfUsers() {
			String sql="SELECT * FROM user";
			List<User> listOfUsers = jdbcTemplate.query(sql, new RowMapper<User>() {
				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
					user.setUserId(rs.getInt("userId"));
					user.setEmail(rs.getString("email"));
					user.setFullname(rs.getString("fullname"));
					return user;
				}
			});
			return listOfUsers;
		}

		@Override
		public User findUserById(int userId) {
			String sql="SELECT * FROM user WHERE userId='" + userId +"'";
			return jdbcTemplate.queryForObject(sql,BeanPropertyRowMapper.newInstance(User.class));
		}

		@Override
		public void updateUserRegistration(User user) {
			String sql = "UPDATE user SET fullname=?, email=? WHERE userId=?";
			jdbcTemplate.update(sql, user.getFullname(), user.getEmail(),user.getUserId());
			
		}
		@Override
		public void deleteUserRegistration(String email) {
		    String sql = "DELETE FROM user WHERE email = ?";
		    jdbcTemplate.update(sql, email);
		}

		@Override
		public void savePassword(String cppassword, String email) {
			String sql = "UPDATE user SET cppassword=? WHERE email=?";
			jdbcTemplate.update(sql, cppassword, email);
		}



}

