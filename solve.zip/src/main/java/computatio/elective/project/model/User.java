package computatio.elective.project.model;

import org.springframework.stereotype.Component;

@Component
public class User {
	private int userId;
	private String fullname;
	private String email;
	private String cppassword;

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getCppassword() {
		return cppassword;
	}
	public void setCppassword(String cppassword) {
		this.cppassword = cppassword;
	}	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

}
