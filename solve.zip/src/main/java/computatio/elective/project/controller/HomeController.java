package computatio.elective.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import computatio.elective.project.model.User;

import computatio.elective.project.MailUtil;
import computatio.elective.project.dao.UserRegistrationDao;

@Controller
public class HomeController {
	@Autowired
	private User user;
	
	@Autowired
	private UserRegistrationDao userRegistrationDao;
	
	@RequestMapping("/main")
	public String mainPage() {
	return "index";
	}
	
	@RequestMapping("/main2")
	public String main2Page() {
	return "index2";
	}
	
	@RequestMapping("/register")
	public String signupPage() {
		return "register";
	}
	
	@RequestMapping("/reset")
	public String resetPage() {
		return "resetpassword";
	}
	
	@RequestMapping("/invalidEmail")
	public String invalidEmail() {
	return "error";
	}
	
	@RequestMapping("/deleteUser")
	public String deletePage() {
		return "delete";
	}
	
	@RequestMapping("/editUser")
	public String editPage() {
		return "edit";
	}
	
	@RequestMapping("/manage")
	public String managePage() {
		return "manage";
	}
	
	@RequestMapping("/signin")public String signinPage() {return "signin";}
	
	@RequestMapping("/formula")public String formulaPage() {return "formula";}
	
	@RequestMapping("/ke")public String kineticEnergy() {return "/formulas/physics/ke";}	
	@RequestMapping("/pe")public String potentialEnergy() {return "/formulas/physics/pe";}	
	@RequestMapping("/hr")public String heatRate() {return "/formulas/physics/hr";}
	@RequestMapping("/li")public String lightning() {return "/formulas/physics/li";}
	@RequestMapping("/hub")public String hubble() {return "/formulas/physics/hub";}
	@RequestMapping("/tem")public String temp() {return "/formulas/physics/tem";}
	@RequestMapping("/ren")public String radEn() {return "/formulas/physics/ren";}
	@RequestMapping("/fr")public String froude() {return "/formulas/physics/fr";}
	@RequestMapping("/enc")public String enCon() {return "/formulas/physics/enc";}
	
	@RequestMapping("/gasp")public String gasPressure() {return "/formulas/chemistry/gasp";}
	@RequestMapping("/igasp")public String igasPressure() {return "/formulas/chemistry/igasp";}
	@RequestMapping("/per")public String percentageYield() {return "/formulas/chemistry/per";}
	
	@RequestMapping("/acirc")public String areaCircle() {return "/formulas/geometry/acirc";}
	@RequestMapping("/ccirc")public String circCircle() {return "/formulas/geometry/ccirc";}
	@RequestMapping("/vcy")public String volCyl() {return "/formulas/geometry/vcy";}
	@RequestMapping("/vcon")public String volCon() {return "/formulas/geometry/vcon";}
	@RequestMapping("/sas")public String saSph() {return "/formulas/geometry/sas";}
	@RequestMapping("/vsp")public String volSph() {return "/formulas/geometry/vsp";}
	
	@RequestMapping("/validate")
	public String validateEmailAddress(Model model, @RequestParam("email") String email, @RequestParam("cppassword") String cppassword) {
		
		user = userRegistrationDao.findByEmail(email);
		if (user==null) {
			model.addAttribute("invalid", "Invalid Input! Please try again.");
			return "signin";
		}

		boolean checkPassword = BCrypt.checkpw(cppassword, user.getCppassword());
		if (!checkPassword) {
			model.addAttribute("invalid", "Invalid Input! Please try again.");
			return "signin";
		}
		model.addAttribute("email", user.getEmail());
		model.addAttribute("fullname", user.getFullname());
		return "formula";
	}
	
	
	@RequestMapping(value="/saveuser", method=RequestMethod.POST)
	public String saveUser(Model model, @RequestParam("email") String email, @RequestParam("password") String password, @RequestParam("fullname") String fullname, @RequestParam("cppassword") String cppassword) {
		

		user.setEmail(email);
		user.setFullname(fullname);
		String salt = BCrypt.gensalt(10);
		String epassword = BCrypt.hashpw(cppassword, salt);
		user.setCppassword(epassword);
		//save email, fullname, and password at db	
		int result = userRegistrationDao.saveUserRegistration(user);
		if (result>0) {
			System.out.println("Data saved succesfully");
				
		}			
		return "redirect:/register?success"; //successful login	
	}
	

	
	//@RequestParam("myEmail") String myEmail, @RequestParam("password") String password,
		@RequestMapping("/resetpassword")
		public String resetPasswordPage(Model model, @RequestParam("recipient") String recipient) {
			user = userRegistrationDao.findByEmail(recipient);
			if (user==null) {
				model.addAttribute("invalid", "Invalid Input! Please try again.");
				return "signin";
			}
			//sendMail ay nakastatic kaya di kailangan mag define ng object for the mail
			MailUtil.sendMail(recipient);
			model.addAttribute("checkemail", "Please check your email to change password.");
			return "resetpassword";
		}
		
		@RequestMapping("/resetpassword/{recipient}")
		public String resetPassword(Model model, @PathVariable("recipient") String recipient) {
			user = userRegistrationDao.findByEmail(recipient);
			model.addAttribute("email", recipient);
			return "resetpasswd";
		}
		@RequestMapping(value="/savepassword", method=RequestMethod.POST)
		public String savePassword(Model model, @RequestParam("cppassword") String cppassword, @RequestParam("email") String email) {
			String salt = BCrypt.gensalt(10);
			String epassword = BCrypt.hashpw(cppassword, salt);
			user.setCppassword(epassword);
			System.out.println(user.getCppassword()+user.getEmail());
			userRegistrationDao.savePassword(epassword, email);
			return "signin";
		}
		
		@RequestMapping("/logout")
		public String logout() {
			return "index";
		}
	
	@RequestMapping("/edit")
	public String editUserPage(Model model, @RequestParam("recipient") String recipient) {
		user = userRegistrationDao.findByEmail(recipient);
		model.addAttribute("email", user.getEmail());
		model.addAttribute("fullname", user.getFullname());
		return "update";
	}

	@RequestMapping("/delete")
	public String deleteUser(@RequestParam("recipient") String recipient) {
		user = userRegistrationDao.findByEmail(recipient);
		userRegistrationDao.deleteUserRegistration(recipient);
		return "index";
	}

	@RequestMapping("/updateUser")
	public String updateUserPage(Model model, @RequestParam("fullname") String fullname, @RequestParam("email") String email) {
		user.setFullname(fullname);
		user.setEmail(email);

		userRegistrationDao.updateUserRegistration(user);
		return "redirect:/manage?success";

	}

	
}
