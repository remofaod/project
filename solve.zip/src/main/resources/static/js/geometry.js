function solveAcirc(){
	let r = document.getElementById("r");
	
	if (r.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("acirc").innerHTML = "Area of a Circle (unit&sup2): " + Math.PI*(r.value*r.value);
	return true;}	
}

function solveCcirc(){
	let r = document.getElementById("r");
	
	if (r.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("ccirc").innerHTML = "Circumference of a Circle (unit): " + 2*Math.PI*r.value;
	return true;	}
}

function solveVcy(){
	let r = document.getElementById("r");
	let h = document.getElementById("h");
	
	if (r.value==""||h.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("vcy").innerHTML = "Volume of a Cylinder (unit&sup3): " + Math.PI*h.value*(r.value*r.value);
	return true;	}
}

function solveVcon(){
	let r = document.getElementById("r");
	let h = document.getElementById("h");
	
	if (r.value==""||h.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("vcon").innerHTML = "Volume of a Cone (unit&sup3): " + (1/3)*Math.PI*h.value*(r.value*r.value);
	return true;	}
}

function solveSas(){
	let r = document.getElementById("r");
	
	if (r.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("sas").innerHTML = "Surface Area of a Sphere (unit&sup2): " + 4*Math.PI*(r.value*r.value);
	return true;	}
}

function solveVsp(){
	let r = document.getElementById("r");
	
	if (r.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("vsp").innerHTML = "Volume of a Sphere (unit&sup3): " + (4/3)*Math.PI*(r.value*r.value*r.value);
	return true;	}
}