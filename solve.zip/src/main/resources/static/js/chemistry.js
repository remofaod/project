function solveGasp(){
	let f = document.getElementById("f");
	let a = document.getElementById("a");
	
	if (f.value==""||a.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
		document.getElementById("gasp").innerHTML = "Gas Pressure (Pascal): " + f.value / a.value;
		return true;
	}		
}

function solveIgasp(){
	let n = document.getElementById("n");
	let t = document.getElementById("t");
	let v = document.getElementById("v");
	
	if (n.value==""||t.value==""||v.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("igasp").innerHTML = "Ideal Gas Pressure (Pascal): " + (n.value*t.value*0.082)/v.value;
	return true;}	
}

function solvePer(){
	let a = document.getElementById("a");
	let t = document.getElementById("t");
	
	if (t.value==""||a.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("per").innerHTML = "Percentage Yield (%): " + (a.value/t.value)*100;
	return true;}
}
