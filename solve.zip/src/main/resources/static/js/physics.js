function solveKe(){
	let mass = document.getElementById("mass");
	let velocity = document.getElementById("velocity");
	
	if (mass.value==""||velocity.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("ke").innerHTML = "Kinetic Energy (J): " + 0.5 * mass.value * (velocity.value*velocity.value);
	return true;}
}

function solvePe(){
	let mass = document.getElementById("mass");
	let gacce = document.getElementById("gacce");
	let height = document.getElementById("height");
	
	if (mass.value==""||gacce.value==""||height.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("pe").innerHTML = "Potential Energy (J): " + gacce.value * mass.value * height.value;
	return true;}
}
	
function solveHr(){
	let flow = document.getElementById("flow");
	let heat = document.getElementById("heat");
	let temp = document.getElementById("temp");
	
	if (flow.value==""||heat.value==""||temp.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("hr").innerHTML = "Heat Rate (btu/hr): " + flow.value * heat.value * temp.value;
	return true;}
}

function solveLi(){
	let t = document.getElementById("t");
	
	if (t.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("li").innerHTML = "Distance of Lightning (m): " + t.value * 343;
	return true;}
}

function solveRen(){
	let t = document.getElementById("t");

	if (t.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("ren").innerHTML = "Radiant Energy (J): " + Math.pow(t.value, 4)* (5.67*Math.pow(10, -8));
	return true;}
}

function solveHub(){
	let velocity = document.getElementById("velocity");
	let con = document.getElementById("con");
	
	if (con.value==""||velocity.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("hub").innerHTML = "Hubble's Law (Mpc): " + velocity.value/con.value;
	return true;	}
}

function solveTem(){
	let m = document.getElementById("m");
	let c = document.getElementById("c");
	let q = document.getElementById("q");
	
	if (m.value==""||c.value==""||q.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("tem").innerHTML = "Temperature (C): " + q.value / (m.value*c.value);
	return true;	}
}
function solveFr(){
	let l = document.getElementById("l");
	let v = document.getElementById("v");
	
	if (l.value==""||v.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("fr").innerHTML = "Froude Number (Fr): " + v.value / (Math.pow((9.80665*l.value),0.5));
	return true;	}
}

function solveEnc(){
	let t = document.getElementById("t");
	let p = document.getElementById("p");
	
	if (t.value==""||p.value==""){
		alert("Empty fields are not allowed.");		
			return false;
	}else{
	document.getElementById("enc").innerHTML = "Energy Consumption (kWh): " + (p.value*t.value*60*60) / 1000;
	return true;	}
}