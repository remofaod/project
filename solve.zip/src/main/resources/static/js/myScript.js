	function validate(){
		let password = document.getElementById("password");
		let cppassword = document.getElementById("cppassword");
		if (password.value!=cppassword.value) {
			console.log(password.value);
			alert("Passwords didn't match. Try again.");
			return false;
		}
		else{
			return true;
		}
	}
